import flet as ft

# --- Reusable Components ---

class ButtonGrid(ft.GridView):
    """
    A UserControl to display a grid of photos.
    """
    def __init__(self):
        super().__init__()
        

    def build(self):
        buttons = []
        for i in range(50):
            buttons.append(
            ft.ElevatedButton(
                text=f"Button {i}",
                on_click=lambda e: self.show_caption(e),
            )
        )
        gv = ft.GridView(
            runs_count=3,
            max_extent=150,
            spacing=5,
            run_spacing=5,
            child_aspect_ratio=1.0,
            controls=buttons
        )

    def show_caption(self, e):
        # Displays the photo's caption when clicked
        e.page.show_snack_bar(
            ft.SnackBar(ft.Text(f"Caption: {e.control.data}"), open=True)
        )


def main(page: ft.Page):
    """
    The main function for the Flet application.
    """
    def create_grid_buttons(count, tab_name):
        return [
            ft.ElevatedButton(
                text=f"Button {i+1}",
                on_click=lambda e, idx=i+1, name=tab_name: print(f"Clicked {name} - Button {idx}")
            )
            for i in range(count)
        ]
    gv = ft.GridView(
                    expand=1,
                    max_extent=150, # Maximum width for each item
                    child_aspect_ratio=1.0,
                    spacing=10,
                    run_spacing=10,
                    controls=create_grid_buttons(5, "Blog")
                ),
    page.title = "My Flet Portfolio"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.vertical_alignment = ft.MainAxisAlignment.START
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    # --- Sample Photo Data ---
    # Replace this with your own data
   
    # --- App Bar ---
    page.appbar = ft.AppBar(
        leading=ft.Row(
            controls=[
                ft.CircleAvatar(
                    foreground_image_src="nitink.jpg",
                    content=ft.Text("NK"),  # Fallback text
                ),
                ft.Text("Nitin Kotasthane", size=20, weight=ft.FontWeight.BOLD),
            ],
            alignment=ft.MainAxisAlignment.START,
        ),
        leading_width=150,
        center_title=False,
        bgcolor=ft.Colors.SURFACE_CONTAINER_HIGHEST,
        actions=[
            ft.IconButton(ft.Icons.MENU, on_click=lambda _: page.open(page.drawer)),
        ],
    )

    # --- Sidebar (NavigationDrawer) ---
    def sidebar_option_click(e):
        page.go(e.control.data)
        page.close(page.drawer)

    page.drawer = ft.NavigationDrawer(
        controls=[
            ft.NavigationDrawerDestination(
                icon=ft.Icons.HOME,
                label="Home",
                data="/",
            ),
            ft.Divider(height=1),
            ft.NavigationDrawerDestination(
                icon=ft.Icon(ft.Icons.SETTINGS),
                label="Settings",
                data="/settings",
            ),
        ],
        on_change=sidebar_option_click
    )

    # --- Landing Page Content ---
    page.add(
        ft.Tabs(
            selected_index=0,
            animation_duration=300,
            expand=1,
            tabs=[
                ft.Tab(text="Blog", content=ft.GridView(
                    expand=1,
                    max_extent=150, # Maximum width for each item
                    child_aspect_ratio=1.0,
                    spacing=10,
                    run_spacing=10,
                    controls=create_grid_buttons(10, "Blog")
                ),
                       
                       
                       
                ),
                ft.Tab(text="Projects", content=ft.Container(ft.Text("Projects content here...", size=20, text_align=ft.TextAlign.CENTER), alignment=ft.alignment.center)),
                ft.Tab(text="About Me", content=ft.Container(ft.Text("About Me content here...", size=20, text_align=ft.TextAlign.CENTER), alignment=ft.alignment.center)),
            ],
            on_change=lambda e: page.update()
        )
    )

if __name__ == "__main__":
    ft.app(target=main)

